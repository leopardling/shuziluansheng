/* ═══════════════════════════════════════════
   api.js — RESTful API封装 + Mock模式
   ═══════════════════════════════════════════ */

var API = {
  BASE_URL: '/api/v1',
  USE_MOCK: true, // 开发模式使用Mock

  async request(endpoint, options = {}) {
    if (this.USE_MOCK) return MockData.resolve(endpoint);
    const url = this.BASE_URL + endpoint;
    const config = { headers: { 'Content-Type': 'application/json' }, ...options };
    try {
      const res = await fetch(url, config);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (err) {
      console.error('[API]', endpoint, err);
      return null;
    }
  },
  get(endpoint, params) {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.request(endpoint + qs);
  },
  post(endpoint, data) {
    return this.request(endpoint, { method: 'POST', body: JSON.stringify(data) });
  },

  /* 服务组 */
  twin3d: {
    getCampus: () => API.get('/twin3d/campus'),
    getFloor: (fid) => API.get('/twin3d/floor', { fid }),
    getModule: (fid, mid) => API.get('/twin3d/module', { fid, mid }),
    getCabinet: (fid, mid, cid) => API.get('/twin3d/cabinet', { fid, mid, cid }),
  },
  asset: {
    getDashboard: () => API.get('/asset/dashboard'),
    getSpace: (level, id) => API.get('/asset/space', { level, id }),
    getCompute: (dim, id) => API.get('/asset/compute', { dim, id }),
    getLedger: (p) => API.get('/asset/ledger', p),
  },
  flow: {
    getMyInitiated: (p) => API.get('/flow/my-initiated', p),
    getMyTodo: (p) => API.get('/flow/my-todo', p),
    getMyDone: (p) => API.get('/flow/my-done', p),
    getAll: (p) => API.get('/flow/all', p),
  },
  maintain: {
    getDeviceList: (p) => API.get('/maintain/device', p),
    getPredict: () => API.get('/maintain/predict'),
    getSchedule: (p) => API.get('/maintain/schedule', p),
    getRecords: (p) => API.get('/maintain/records', p),
    getProfile: (assetNo) => API.get('/maintain/profile', { assetNo }),
    getInspection: (p) => API.get('/maintain/inspection', p),
  },
  ops: {
    getAlarmList: (p) => API.get('/ops/alarm', p),
    getAlarmStats: () => API.get('/ops/alarm/stats'),
    getWorkorderList: (p) => API.get('/ops/workorder', p),
    getVirtualRack: () => API.get('/ops/virtual-rack'),
    getFaultPredict: () => API.get('/ops/fault-predict'),
  },
  admin: {
    getCluster: () => API.get('/admin/cluster'),
    getAudit: (p) => API.get('/admin/audit', p),
    getBizlog: (p) => API.get('/admin/bizlog', p),
    getAnalytics: () => API.get('/admin/analytics'),
  },
  green: {
    getHeatmap: (moduleNo) => API.get('/green/heatmap', { moduleNo }),
    getPower: (dim, id) => API.get('/green/power', { dim, id }),
    getTopology: (cabinetNo) => API.get('/green/topology', { cabinetNo }),
  }
};

/* ═══════════════════════════════════════════
   MockData — 开发阶段模拟数据
   ═══════════════════════════════════════════ */
var MockData = {
  /* 楼层数据 */
  FLOORS: [
    { id:0, label:'1F', name:'一层', type:'aux', desc:'动力中心 / 辅助用房', modules:[], specials:[], cabTotal:0, util:0 },
    { id:1, label:'2F', name:'二层主机房', type:'dc', desc:'11个微模块 · 标准机房', modules:[], specials:[], cabTotal:0, util:74 },
    { id:2, label:'2F', name:'三层主机房', type:'dc', desc:'11个微模块 · 标准机房', modules:[], specials:[], cabTotal:0, util:68 },
    { id:3, label:'4F', name:'四层主机房', type:'dc', desc:'11个微模块 + 2个异型机房', modules:[], specials:[{id:'S1',name:'异型机房A',cabs:18,util:62},{id:'S2',name:'异型机房B',cabs:16,util:55}], cabTotal:0, util:61 }
  ],

  init() {
    this.FLOORS[1].modules = this._mkModules(11, '2F');
    this.FLOORS[2].modules = this._mkModules(11, '3F');
    this.FLOORS[3].modules = this._mkModules(11, '4F');
    this.FLOORS.forEach(f => {
      f.cabTotal = f.modules.reduce((s,m) => s + m.cabs, 0) + f.specials.reduce((s,r) => s + r.cabs, 0);
      if (!f.util && f.modules.length) f.util = Math.round(f.modules.reduce((s,m) => s + m.util, 0) / f.modules.length);
    });
  },

  _mkModules(n, p) {
    const a = [];
    for (let i = 1; i <= n; i++) {
      const cabs = 18 + (i % 3 === 0 ? 1 : 0);
      a.push({
        id: `${p}-M${String(i).padStart(2,'0')}`, name: `微模块${String(i).padStart(2,'0')}`,
        cabs, ac: 4 + (i % 2 === 0 ? 1 : 0), pw: 1,
        util: 50 + Math.floor(Math.random() * 38),
        temp: (21 + Math.random() * 5).toFixed(1),
        cd: this._mkCabinets(cabs, `${p}-M${String(i).padStart(2,'0')}`)
      });
    }
    return a;
  },

  _mkCabinets(n, p) {
    const a = [];
    for (let i = 1; i <= n; i++) {
      const usage = 30 + Math.floor(Math.random() * 62);
      let st = usage > 90 ? 'warn' : 'ok';
      if (Math.random() < 0.04) st = 'error';
      a.push({ id: `${p}-C${String(i).padStart(2,'0')}`, usage, st, devs: this._mkDevices(usage) });
    }
    return a;
  },

  _mkDevices(up) {
    const tot = 47, used = Math.floor(tot * up / 100), d = [];
    let u = 1;
    while (u <= used) {
      const types = ['srv','srv','srv','srv','stg','net'];
      const t = types[Math.floor(Math.random() * types.length)];
      const h = t === 'stg' ? 2 : 1;
      if (u + h - 1 <= used) {
        let ds = 'ok';
        const r = Math.random();
        if (r < 0.03) ds = 'error';
        else if (r < 0.08) ds = 'warn';
        d.push({
          s: u, e: u + h - 1, type: t, status: ds,
          mdl: t === 'srv' ? ['FusionServer 2288H','NF5280M7','R4900 G6','PowerEdge R760'][Math.floor(Math.random()*4)] :
               t === 'stg' ? 'OceanStor 5310' : t === 'net' ? 'CE12800' : 'PDU-A'
        });
        u += h;
      } else break;
    }
    return d;
  },

  _calcGlobal() {
    let srv = 0, stg = 0, net = 0;
    this.FLOORS.forEach(f => f.modules.forEach(m => m.cd.forEach(c => c.devs.forEach(d => {
      if (d.type === 'srv') srv++; else if (d.type === 'stg') stg++; else net++;
    }))));
    return { srv, stg, net, total: srv + stg + net, cpuPf: (srv * 0.135).toFixed(1), gpuPf: (srv * 0.58).toFixed(1), npuPf: (srv * 0.038).toFixed(1) };
  },

  resolve(endpoint) {
    if (!this.FLOORS[1].modules.length) this.init();
    const G = this._calcGlobal();

    // 路由匹配
    if (endpoint.includes('/twin3d/campus')) {
      return {
        parkCode: 'CY', deviceTotal: G.total, cabinetTotal: 612, moduleTotal: 33,
        cpuPflops: G.cpuPf, gpuPflops: G.gpuPf, npuPflops: G.npuPf,
        designPowerMW: 12.0, itPowerMW: 6.18, pueIndex: 1.32, floors: this.FLOORS,
        vendors: [
          { vendorName:'华为', deviceModel:'FusionServer 2288H', count:624, ratio:'37.8%', status:'ok' },
          { vendorName:'浪潮', deviceModel:'NF5280M7', count:418, ratio:'25.3%', status:'ok' },
          { vendorName:'新华三', deviceModel:'R4900 G6', count:356, ratio:'21.5%', status:'ok' },
          { vendorName:'Dell', deviceModel:'PowerEdge R760', count:254, ratio:'15.4%', status:'warn' }
        ],
        statusStats: [
          { label:'正常运行', count:2589, ratio:'93.2%', status:'ok' },
          { label:'告警', count:148, ratio:'5.3%', status:'warn' },
          { label:'故障', count:15, ratio:'0.5%', status:'error' },
          { label:'维护中', count:28, ratio:'1.0%', status:'maintain' }
        ]
      };
    }

    if (endpoint.includes('/twin3d/floor')) {
      const fid = parseInt(new URLSearchParams(endpoint.split('?')[1]).get('fid') || '1');
      return this.FLOORS[fid] || this.FLOORS[1];
    }

    if (endpoint.includes('/twin3d/module')) {
      const params = new URLSearchParams(endpoint.split('?')[1]);
      const fid = parseInt(params.get('fid') || '1');
      const mid = parseInt(params.get('mid') || '0');
      const fl = this.FLOORS[fid] || this.FLOORS[1];
      return fl.modules[mid] || fl.modules[0];
    }

    if (endpoint.includes('/twin3d/cabinet')) {
      const params = new URLSearchParams(endpoint.split('?')[1]);
      const fid = parseInt(params.get('fid') || '1');
      const mid = parseInt(params.get('mid') || '0');
      const cid = parseInt(params.get('cid') || '0');
      const fl = this.FLOORS[fid] || this.FLOORS[1];
      const mod = fl.modules[mid] || fl.modules[0];
      return mod.cd[cid] || mod.cd[0];
    }

    if (endpoint.includes('/asset/dashboard')) {
      return {
        deviceTotal: G.total, cabinetTotal: 612, uUsageRate: 73.5, assetValue: 128600000,
        moduleTotal: 33, pueIndex: 1.32,
        categoryPie: [
          { name:'服务器', value:G.srv, ratio:((G.srv/G.total)*100).toFixed(1) },
          { name:'存储设备', value:G.stg, ratio:((G.stg/G.total)*100).toFixed(1) },
          { name:'网络设备', value:G.net, ratio:((G.net/G.total)*100).toFixed(1) }
        ],
        vendors: this._calcGlobal ? [
          { vendorName:'华为', count:624, ratio:'37.8%' },
          { vendorName:'浪潮', count:418, ratio:'25.3%' },
          { vendorName:'新华三', count:356, ratio:'21.5%' },
          { vendorName:'Dell', count:254, ratio:'15.4%' }
        ] : []
      };
    }

    // 默认返回空
    return {};
  }
};

// 初始化Mock数据
MockData.init();
