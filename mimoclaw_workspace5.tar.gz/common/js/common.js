/* ═══════════════════════════════════════════
   common.js — 公共脚本
   省级智慧数据中心数字孪生系统
   提供: App(面包屑/路径) Router(页面跳转) 时钟 导航高亮 侧边栏收起
   ═══════════════════════════════════════════ */

/* ── App 全局对象 ── */
var App = {
  /* 计算从当前页面到 digital-twin 根目录的相对路径 */
  getRelativeRoot: function() {
    var path = decodeURIComponent(window.location.pathname).replace(/\\/g, '/');
    var parts = path.split('/').filter(Boolean);
    var dtIdx = -1;
    for (var i = parts.length - 1; i >= 0; i--) {
      if (parts[i] === 'digital-twin') { dtIdx = i; break; }
    }
    if (dtIdx !== -1) {
      var afterDt = parts.slice(dtIdx + 1);
      var dirCount = afterDt.length > 0 && afterDt[afterDt.length - 1].indexOf('.html') !== -1
        ? afterDt.length - 1 : afterDt.length;
      return dirCount <= 0 ? '' : new Array(dirCount + 1).join('../');
    }
    var last = parts[parts.length - 1] || '';
    if (last.indexOf('.html') !== -1) return '../';
    return '';
  },

  /* 设置面包屑 */
  setBreadcrumb: function(items) {
    var el = document.getElementById('app-breadcrumb');
    if (!el) return;
    var html = '';
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var sep = i < items.length - 1 ? ' <span class="bc-sep">›</span> ' : '';
      var cls = item.active ? ' active' : '';
      var click = '';
      if (item.href) {
        click = ' onclick="Router.navigate(\'' + item.href + '\')" style="cursor:pointer"';
      }
      html += '<span class="bc-item' + cls + '"' + click + '>' + (item.label || item.name || '') + '</span>' + sep;
    }
    el.innerHTML = html;
  }
};

/* ── Router 全局对象 ── */
var Router = {
  getParam: function(key) {
    return new URLSearchParams(window.location.search).get(key);
  },
  navigate: function(page, params) {
    var root = App.getRelativeRoot();
    var qs = '';
    if (params) {
      var pairs = [];
      for (var k in params) {
        if (params.hasOwnProperty(k)) {
          pairs.push(encodeURIComponent(k) + '=' + encodeURIComponent(params[k]));
        }
      }
      if (pairs.length > 0) qs = '?' + pairs.join('&');
    }
    window.location.href = root + page + qs;
  }
};

/* ── DOMContentLoaded ── */
document.addEventListener('DOMContentLoaded', function() {
  /* 时钟 */
  var clock = document.getElementById('app-clock');
  if (clock) {
    function pad(v) { return String(v).padStart(2, '0'); }
    function tick() {
      var n = new Date();
      clock.textContent = n.getFullYear() + '-' + pad(n.getMonth() + 1) + '-' + pad(n.getDate()) +
        ' ' + pad(n.getHours()) + ':' + pad(n.getMinutes()) + ':' + pad(n.getSeconds());
    }
    tick();
    setInterval(tick, 1000);
  }

  /* 高亮当前页面导航 */
  var path = decodeURIComponent(window.location.pathname).replace(/\\/g, '/');
  var items = document.querySelectorAll('.sidebar-item');
  for (var i = 0; i < items.length; i++) {
    var href = items[i].getAttribute('href') || '';
    var clean = href.replace(/^\.\.\//, '');
    if (path.indexOf(clean) !== -1 && clean.length > 0) {
      items[i].classList.add('active');
    }
  }

  /* 侧边栏一级菜单收起/展开（手风琴） */
  var toggles = document.querySelectorAll('.sidebar-section-title[data-toggle]');
  for (var t = 0; t < toggles.length; t++) {
    toggles[t].addEventListener('click', function() {
      var groupId = this.getAttribute('data-toggle');
      var children = this.nextElementSibling;
      if (!children || !children.classList.contains('sidebar-children')) return;
      var isOpen = children.classList.contains('open');
      this.classList.toggle('collapsed', isOpen);
      children.classList.toggle('open', !isOpen);
      localStorage.setItem('dt-menu-' + groupId, isOpen ? 'collapsed' : 'open');
    });
  }

  /* 恢复一级菜单状态 */
  var saved = {};
  try {
    for (var k = 0; k < localStorage.length; k++) {
      var key = localStorage.key(k);
      if (key && key.indexOf('dt-menu-') === 0) {
        saved[key.replace('dt-menu-', '')] = localStorage.getItem(key);
      }
    }
  } catch(e) {}
  var sections = document.querySelectorAll('.sidebar-section[data-group]');
  for (var s = 0; s < sections.length; s++) {
    var group = sections[s].getAttribute('data-group');
    if (saved[group] === 'collapsed') {
      var title = sections[s].querySelector('.sidebar-section-title');
      var child = sections[s].querySelector('.sidebar-children');
      if (title && child) {
        title.classList.add('collapsed');
        child.classList.remove('open');
      }
    }
  }

  /* 侧边栏整栏收起/展开 */
  var toggle = document.getElementById('sidebar-toggle');
  if (toggle) {
    if (localStorage.getItem('dt-sidebar-collapsed') === 'true') {
      document.body.classList.add('sidebar-collapsed');
    }
    toggle.addEventListener('click', function() {
      document.body.classList.toggle('sidebar-collapsed');
      localStorage.setItem('dt-sidebar-collapsed', document.body.classList.contains('sidebar-collapsed'));
    });
  }
});
