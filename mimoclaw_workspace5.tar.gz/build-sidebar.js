#!/usr/bin/env node
/**
 * build-sidebar.js — 注入静态 sidebar/header/footer + sidebar toggle + accordion
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname);

const ITEM_ICONS = {
  '3d/campus.html': '🏢', '3d/floor.html': '📊', '3d/module.html': '📦', '3d/cabinet.html': '🗄️',
  'asset/dashboard.html': '📈', 'asset/space.html': '📐', 'asset/compute.html': '💻',
  'asset/ledger.html': '📋', 'asset/model-mgmt.html': '🎨',
  'lifecycle/flow-design.html': '🔄', 'lifecycle/mapping.html': '🔗',
  'lifecycle/my-initiated.html': '📤', 'lifecycle/my-todo.html': '📥',
  'lifecycle/my-done.html': '✅', 'lifecycle/all-flows.html': '📑', 'lifecycle/search.html': '🔍',
  'maintain/overview.html': '🖥️', 'maintain/predict.html': '🔮', 'maintain/schedule.html': '📅',
  'maintain/records.html': '📝', 'maintain/profile.html': '👤', 'maintain/inspection.html': '🔎',
  'ops/virtual-rack.html': '🏗️', 'ops/alarm.html': '🚨', 'ops/fault-predict.html': '⚡', 'ops/workorder.html': '🎫',
  'admin/cluster.html': '🖥️', 'admin/audit.html': '📜', 'admin/bizlog.html': '📄', 'admin/analytics.html': '📊',
  'green/heatmap.html': '🌡️', 'green/power.html': '⚡', 'green/topology.html': '🔌'
};

const MENU = [
  { id:'twin3d', label:'数字孪生3D', icon:'◇', children:[
    {label:'园区总览', href:'3d/campus.html'},{label:'楼层视图', href:'3d/floor.html'},{label:'微模块视图', href:'3d/module.html'},{label:'机柜视图', href:'3d/cabinet.html'}
  ]},
  { id:'asset', label:'资产管理', icon:'▦', children:[
    {label:'资产统计看板', href:'asset/dashboard.html'},{label:'空间统计分析', href:'asset/space.html'},{label:'算力统计分析', href:'asset/compute.html'},{label:'资产台账查询', href:'asset/ledger.html'},{label:'3D资产建模管理', href:'asset/model-mgmt.html'}
  ]},
  { id:'lifecycle', label:'资产生命周期', icon:'⟲', children:[
    {label:'全生命周期流程', href:'lifecycle/flow-design.html'},{label:'资产双向映射', href:'lifecycle/mapping.html'},{label:'我发起的流程', href:'lifecycle/my-initiated.html'},{label:'我的待办流程', href:'lifecycle/my-todo.html'},{label:'我的已办流程', href:'lifecycle/my-done.html'},{label:'所有流程', href:'lifecycle/all-flows.html'},{label:'资产查询检索', href:'lifecycle/search.html'}
  ]},
  { id:'maintain', label:'设备维护管理', icon:'⚙', children:[
    {label:'设备信息总览', href:'maintain/overview.html'},{label:'预测性维护', href:'maintain/predict.html'},{label:'维护计划与排程', href:'maintain/schedule.html'},{label:'维修记录与知识库', href:'maintain/records.html'},{label:'设备数字画像', href:'maintain/profile.html'},{label:'巡检档案数字化', href:'maintain/inspection.html'}
  ]},
  { id:'ops', label:'智能运维', icon:'⬡', children:[
    {label:'虚拟上架管理', href:'ops/virtual-rack.html'},{label:'故障告警中心', href:'ops/alarm.html'},{label:'故障预测分析', href:'ops/fault-predict.html'},{label:'工单系统', href:'ops/workorder.html'}
  ]},
  { id:'admin', label:'运营后台', icon:'⊞', children:[
    {label:'集群节点监控', href:'admin/cluster.html'},{label:'审计日志管理', href:'admin/audit.html'},{label:'业务日志管理', href:'admin/bizlog.html'},{label:'数据分析决策', href:'admin/analytics.html'}
  ]},
  { id:'green', label:'绿色节能', icon:'🌿', children:[
    {label:'机柜热力分布图', href:'green/heatmap.html'},{label:'功耗统计分析', href:'green/power.html'},{label:'配电拓扑分析', href:'green/topology.html'}
  ]}
];

function getRelRoot(pageRelPath) {
  const parts = pageRelPath.split('/');
  return parts.length - 1 === 0 ? '' : '../'.repeat(parts.length - 1);
}

function genSidebar(root, activeHref) {
  let html = '';
  MENU.forEach(g => {
    // Check if any child is active
    const hasActive = g.children.some(c => c.href === activeHref);
    const collapsed = hasActive ? '' : ' collapsed';
    html += `<div class="sidebar-section" data-group="${g.id}">`;
    html += `<div class="sidebar-section-title${collapsed}" data-toggle="${g.id}"><span class="sec-icon">${g.icon}</span><span class="sec-label">${g.label}</span><span class="sec-arrow">▸</span></div>`;
    html += `<div class="sidebar-children${collapsed ? '' : ' open'}">`;
    g.children.forEach(c => {
      const fullHref = root + c.href;
      const active = c.href === activeHref ? ' active' : '';
      const icon = ITEM_ICONS[c.href] || '•';
      html += `<a class="sidebar-item${active}" href="${fullHref}" data-icon="${icon}">${c.label}</a>`;
    });
    html += '</div></div>';
  });
  return html;
}

function genHeader(root) {
  return `<div class="hdr-left"><button class="sidebar-toggle" id="sidebar-toggle" title="收起/展开侧边栏"><span class="toggle-icon">◀</span></button><a href="${root}index.html" style="display:flex;align-items:center;gap:14px;text-decoration:none;color:inherit"><div class="hdr-logo">DT</div><div><div class="hdr-title">省级智慧数据中心</div><div class="hdr-subtitle">DIGITAL TWIN INTELLIGENT SYSTEM · 茶园主楼</div></div></a></div><div class="hdr-right"><div class="hdr-status"><span class="status-light"></span><span>系统运行正常</span></div><div class="hdr-pue">PUE <span class="val">1.32</span></div><div class="hdr-time" id="app-clock">--</div></div>`;
}

function genFooter() {
  return `<div class="footer-left"><div class="footer-item"><span class="footer-dot ok"></span>3D渲染引擎</div><div class="footer-item"><span class="footer-dot ok"></span>数据采集</div><div class="footer-item"><span class="footer-dot ok"></span>传感器1248/1248</div><div class="footer-item"><span class="footer-dot warn"></span>告警5条</div></div><div>省级智慧数据中心数字孪生智能系统 v2.1 · STATE GRID FUJIAN</div>`;
}

function findHtml(dir, rel) {
  const results = [];
  for (const item of fs.readdirSync(dir)) {
    if (item === 'common' || item === 'node_modules' || item === 'build-sidebar.js') continue;
    const full = path.join(dir, item);
    const r = rel ? rel + '/' + item : item;
    if (fs.statSync(full).isDirectory()) results.push(...findHtml(full, r));
    else if (item.endsWith('.html')) results.push({ full, rel: r });
  }
  return results;
}

const pages = findHtml(ROOT, '');
console.log(`Found ${pages.length} HTML files`);

let modified = 0;
for (const page of pages) {
  let html = fs.readFileSync(page.full, 'utf8');
  const root = getRelRoot(page.rel);
  const sidebarHtml = genSidebar(root, page.rel);
  const headerHtml = genHeader(root);
  const footerHtml = genFooter();
  let changed = false;

  if (html.includes('id="app-sidebar"')) {
    html = html.replace(
      /(<div\s+id="app-sidebar"\s+class="app-sidebar">)([\s\S]*?)(<\/div>\s*(?=<main|<\/main|<div id="app-footer|<script|<\/body))/,
      `$1${sidebarHtml}$3`
    );
    changed = true;
  }
  if (html.includes('id="app-header"')) {
    html = html.replace(
      /(<div\s+id="app-header"\s+class="app-header">)([\s\S]*?)(<\/div>\s*(?=<div id="app-sidebar|<main))/,
      `$1${headerHtml}$3`
    );
    changed = true;
  }
  if (html.includes('id="app-footer"')) {
    html = html.replace(
      /(<div\s+id="app-footer"\s+class="app-footer">)([\s\S]*?)(<\/div>\s*(?=<script|<\/body))/,
      `$1${footerHtml}$3`
    );
    changed = true;
  }

  if (changed) {
    fs.writeFileSync(page.full, html);
    modified++;
    console.log(`  ✓ ${page.rel}`);
  }
}
console.log(`\nDone: ${modified}/${pages.length} files updated`);
